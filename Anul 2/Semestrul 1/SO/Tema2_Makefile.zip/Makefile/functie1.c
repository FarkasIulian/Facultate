#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>

void fisiere(char *nume,char*dest){  		
	struct stat stare; 
	int fisier1,fisier2,lungime; 
	char text[100000]; 
	fisier1=open(nume,O_RDONLY); 
	stat(nume,&stare);
	fisier2=open(dest,O_CREAT|O_WRONLY,stare.st_mode);
	lungime=read(fisier1, text, stare.st_size);
	write(fisier2, text, lungime); 
	close(fisier1);
	close(fisier2);
}

