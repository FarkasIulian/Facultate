void citire(char *nume,char*dest);
