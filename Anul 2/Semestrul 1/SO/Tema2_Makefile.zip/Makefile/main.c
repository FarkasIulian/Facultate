#include "functie2.h"
#include <string.h>

int main(int argc, char *argv[]){	
	char director_s[100],director_d[100];
	strcpy(director_s,argv[1]);
	strcpy(director_d,argv[2]);
	citire(director_s,director_d);
return 0;
}
