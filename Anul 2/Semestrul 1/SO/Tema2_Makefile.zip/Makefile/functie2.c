#include "functie1.h"

void citire(char *nume,char*dest){ 
	DIR *dr; 
	struct dirent *entryData; 
	struct stat stare;
	char destinatie[1000],curent[1000]; 
	dr=opendir(nume);
	while((entryData=readdir(dr))!=NULL ){
		stat(nume,&stare);
		mkdir(dest,stare.st_mode);
		if((strcmp(entryData->d_name,".")!=0) && (strcmp(entryData->d_name,"..")!=0)){
			strcpy(curent,nume);
			strcpy(destinatie,dest);
			if(curent[strlen(curent)-1]!='/')
				strcat(curent,"/");
			if(destinatie[strlen(destinatie)-1]!='/')
				strcat(destinatie,"/");	
			strcat(curent,entryData->d_name);
			strcat(destinatie,entryData->d_name);
			stat(curent,&stare);
			if(S_ISDIR(stare.st_mode))
				citire(curent,destinatie);
			if(S_ISREG(stare.st_mode)){ 
				if(stare.st_size>500){
					fisiere(curent,destinatie);
					chmod(destinatie, stare.st_mode | S_IWGRP+S_IWOTH+S_IWUSR );
					}
				if(stare.st_size >300 && stare.st_size <500){	
					link(curent,destinatie);
					}
				if(stare.st_size <300){
					symlink(curent,destinatie);
				}
			}
		}	
	}
	closedir(dr);
}
